# Testing Rules

Every implementation should include small tests and edge cases.
