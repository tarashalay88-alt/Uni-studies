# ADS Exam Checklist

For every algorithm/data structure, prepare:

- invariant
- operation
- correctness proof
- runtime
- edge cases
- implementation
- one hand-simulated example
