# Algorithms and Data Structures Exam Prep

Focus on correctness, invariants, runtime, and implementation.

## Core blocks

- asymptotic notation
- recursion and induction
- sorting
- trees
- AVL / red-black trees
- heaps
- hashing
- graphs
- dynamic programming
