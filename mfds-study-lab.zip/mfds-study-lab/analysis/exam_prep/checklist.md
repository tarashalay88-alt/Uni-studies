# Analysis Exam Checklist

For every topic, prepare:

- exact definition
- intuition
- standard theorem
- proof skeleton
- standard example
- counterexample
- common trap
