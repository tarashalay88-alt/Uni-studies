# Analysis Exam Prep

Focus on definitions, theorem proof skeletons, and examples/counterexamples.

## Core blocks

- metric spaces
- convergence and Cauchy sequences
- completeness and compactness
- continuity and uniform continuity
- differentiability
- integration
- multivariable analysis
- constrained extrema
