# Micro-Proofs

Use this for 5-10 minute proof warmups.

## Template

### Statement

### First attempt

### Clean proof

### Reusable idea

---

## Examples to add

- `ker T` is a subspace.
- `im T` is a subspace.
- If `P^2 = P`, then `V = ker P ⊕ im P`.
- If `U ⊆ V`, then `U^◦` is a subspace of `V*`.
