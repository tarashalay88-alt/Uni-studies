# Linear Algebra Exam Checklist

## Must be automatic

- vector spaces, subspaces
- kernels and images
- direct sums and projections
- dual spaces and annihilators
- inner products and orthogonality
- adjoints
- determinants
- eigenvalues and diagonalization

## For each theorem

- statement
- proof idea
- clean proof
- example
- false neighboring statement
- counterexample
