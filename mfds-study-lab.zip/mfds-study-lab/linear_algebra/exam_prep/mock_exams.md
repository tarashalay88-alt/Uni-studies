# Linear Algebra Mock Exams

## Mock template

Time: 90 minutes

1. One subspace/direct sum proof.
2. One dual/annihilator proof.
3. One inner product/adjoint proof.
4. One determinant proof.
5. One eigenvalue/diagonalization proof.
6. One counterexample.
